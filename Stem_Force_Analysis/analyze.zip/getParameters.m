close all; clear all; clc

dt = 1/1000;
ftd = dlmread('ft_log.txt');

t = 0:dt:(dt*length(ftd)-dt);
mag = sqrt(ftd(:,2).^2 + ftd(:,3).^2 + ftd(:,4).^2);

C = smoothdata(mag,'gaussian',1000);
plot(t,C);


F = abs(C(end)-C(1));
h = 0.1;
theta = degtorad(20);

K = (F * h) / (cos(theta)^2*theta);