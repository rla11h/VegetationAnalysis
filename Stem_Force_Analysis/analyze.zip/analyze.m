close all; clear all; clc

dt = 1/1000;
ftd = dlmread('02_08_18/test_3.txt');
t = ftd(:,1) - ftd(1,1);
fx = ftd(:,2);
fy = ftd(:,3);
fz = -ftd(:,4);
tx = ftd(:,5);
ty = ftd(:,6);
tz = ftd(:,7); 
ex = ftd(:,8);
ey = ftd(:,9);
ez = -ftd(:,10);

subplot(3,1,1)
plot(t,fz,'b-');
grid minor; hold on;
title('Signal')

% LOW PASS
zlp = filter(0.01,[1 -0.99],fz);
subplot(3,1,2);
plot(t,zlp);
title('Low Pass');
grid minor;
%ylim([38 48])

subplot(3,1,3)
C = smoothdata(fz,'gaussian',1000);
plot(t,C);
title('Gaussian Smoothed');
grid minor

figure(2)
plot(t,fz); hold on;
plot(t,C,'r-','LineWidth',3)
xlim([0 t(end)]);


f = []

figure
plot(t,C); hold on
n = 0;
for i=2:length(t)
    
  e = abs(ex(i)-ex(i-1));
  
  if(e>0)
   % plot(t(i),ez(i),'ro');
   f = [f;t(i) ex(i)];
  end
    
    
end





